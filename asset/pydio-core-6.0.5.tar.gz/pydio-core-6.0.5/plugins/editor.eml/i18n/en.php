<?php
$mess = array(
"name" => "Email Viewer",
"title" => "Email Viewer",
"1" => "From",
"2" => "To",
"3" => "Subject",
"4"	=> "Date",
"5" => "Attachments",
"6" => "Download EML",
"7" => "Attachment %s was successfully copied to %s",
"8" => "Could not open destination file!",
"9" => "Could not find attachment!",
"10" => "Download ",
"11" => "Copy attachment on the server",
"12" => "Cc",
);
