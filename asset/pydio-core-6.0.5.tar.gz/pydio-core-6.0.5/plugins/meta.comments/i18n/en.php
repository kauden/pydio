<?php

$mess = array(
"1" => "Users Comments",
"2" => "Enter your comment here",
"3" => "Post",
"4" => "Go to %s",
);
