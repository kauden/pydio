<?php

$mess = array(
"1" => "Commentaires des utilisateurs",
"2" => "Entrez votre commentaire ici",
"3" => "Envoyer",
"4" => "Aller à %s",
);
