<?php

$mess = array(
"1" => "Ortsangabe",
"2" => "Karte",
);
