<?php

$mess = array(
"1" => "GeoLocation",
"2" => "Locate",
);
