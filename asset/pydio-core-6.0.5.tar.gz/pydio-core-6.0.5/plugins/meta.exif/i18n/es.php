<?php

$mess = array(
"1" => "GeoUbicación",
"2" => "Ubicar",
);
