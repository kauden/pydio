<?php
/*
* Multi shortener plugin for ajaXplorer by FrenandoAloso
*         based in bit.ly plugin
*/
$mess=array(
"Multi URL Shortener" => "Multi acortador de URL",
"Shorten Download Links before sending them back to the user." => "Acorta los enlaces de descarga antes de mostrarlos al usuario.",
"User ID" => "ID de usuario",
"adF.ly account user ID.\nThe numbers after -= ?id= =- in of your referral program's URL" => "ID de usuario de tu cuenta de adF.ly.\nLos numeros tras el -= ?id= =- en tu URL del 'referral program'",
"API Key" => "Clave de API",
"adF.ly account API Key" => "Clave de API de tu cuenta de adF.ly",
"Type of ADS" => "Tipo de anuncio",
"Type of AD you like to show.\n Select Fullscreen AD or Top banner AD" => "Tipo de Anuncio que quieres usar.\nSelecciona Pantalla completa o Marco superior",
"Short domain" => "Dominio corto",
"adF.ly or q.gs domains, select wich you like" => "Dominio adF.ly o q.gs, elige el que mas te guste",
"FullScreen" => "Pantalla completa",
"Banner" => "Marco superior",
"Bit.ly URL Shortener" => "Acortador de URL Bit.ly",
"Shorten Download Links before sending them back to the user. Requires a Bit.ly account." => "Acorta los enlaces de descarga antes de mostrarlos al usuario. Requiere una cuenta Bit.ly.",
"User Name" => "Usuario",
"Bit.ly account user name" => "Usuario de la cuenta Bit.ly",
"API Key" => "Clave API",
"Bit.ly account API Key" => "Clave API de la cuenta Bit.ly",
"Yourls domain" => "Yourls domain",
"Use IDN" => "Use IDN",
"multi URL Shortener" => "multi URL Shortener",
"Shorten type" => "Shorten type",
);