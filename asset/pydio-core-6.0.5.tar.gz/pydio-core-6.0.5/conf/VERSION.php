<?php
define("AJXP_VERSION", "6.0.5");
define("AJXP_VERSION_DATE", "2015-03-06");
define("AJXP_VERSION_REV", "7ea8a78");
define("AJXP_VERSION_DB", "60");
